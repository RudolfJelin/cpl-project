
#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#define LED_ON "LED ON"
#define LED_OFF "LED OFF"
#define BUT_STAT "BUTT:STATUS?"

#define BUFFER_SIZE 255

#define JOY_NONE 0
#define JOY_UP 1
#define JOY_DOWN 2
#define JOY_LEFT 3
#define JOY_RIGHT 4
#define JOY_SEL 5

#endif
