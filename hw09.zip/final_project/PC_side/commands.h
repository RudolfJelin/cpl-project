
#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#define LED_ON "LED ON"
#define LED_OFF "LED OFF"
#define BUT_STAT "BUTT:STATUS?"

#endif
