gedit main.c list.c list.h serial.c intro.txt main.txt splash.txt &
