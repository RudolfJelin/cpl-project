# cpl-project

- final_project includes the files for the PC and NUCLEO sides including Makefile and various txt's.
- this project was maintained using a git repo: https://github.com/RudolfJelin/cpl-project/final_project

Notes:
- works according to specifications, but with some unspecified limitations:
	- transfer rate seemed to be very limited, I had to manually decrease it to send strings over from PC to NUCLEO
	- LED and user button are unoperable due to conflict with LCD controls
	- files are limited to 10 includes
- some features are additional/not necessairily needed:
	- joystick can initiate clear or resend request; if any transfers are already active, conflicts are resolved
	- files can contain any kind of comment and trailing whitespace/newline malformations
	- probably some other things I already forgot
